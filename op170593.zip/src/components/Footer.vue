<template>
  <footer>
    <p>Copyright 2020, Petar Ostojić, Odsek za Softversko Inženjerstvo Elektrotehničkog fakulteta Univerziteta u Beogradu</p>
  </footer>
</template>

<script>
export default {};
</script>

<style>
footer {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background: var(--main-bg-color);
  color: white;
}
</style>