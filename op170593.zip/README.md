# fitness-center-2

[![Netlify Status](https://api.netlify.com/api/v1/badges/055e3c91-6dc9-4875-833d-99907cb003c9/deploy-status)](https://app.netlify.com/sites/playfitness/deploys)

## Project setup

```
npm install
```

### Compiles and hot-reloads for development

```
npm run serve
```

### Compiles and minifies for production

```
npm run build
```

### Lints and fixes files

```
npm run lint
```

### Customize configuration

See [Configuration Reference](https://cli.vuejs.org/config/).
